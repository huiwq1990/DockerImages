#!/bin/bash

exec java -jar /opt/jenkins/jenkins.war