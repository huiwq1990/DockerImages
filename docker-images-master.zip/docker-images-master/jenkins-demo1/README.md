docker-jenkins
==============

Jenkins for docker
