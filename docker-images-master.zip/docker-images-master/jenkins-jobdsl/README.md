## docker-jenkins ##

Jenkins jobdsl demo for docker, it contains lots of plugin as well

	docker run -it -p 8080:8080 larrycai/jenkins-jobdsl 
	
It mainly for CodingWithMe http://www.slideshare.net/larrycai/learn-jobdsl-for-jenkins 

The related gist of exercises: https://gist.github.com/larrycai/aeb9a3b037dcb17df9b2 

	
## Reference ##
* http://www.slideshare.net/daspilker/configuration-as-code-the-job-dsl-plugin
* https://github.com/jenkinsci/job-dsl-plugin/wiki/View-Reference
* https://github.com/jenkinsci/job-dsl-plugin/wiki/Job-reference
* https://github.com/jenkinsci/job-dsl-plugin/wiki/The-Configure-Block 
	
