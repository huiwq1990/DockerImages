[2~#!/bin/bash
cd /dashing
# bundle install
dashing start
